import LogIn from "@/UI/LogIn";
import RegP from "@/UI/RegP";
import DialogButtons from "@/UI/DialogButtons";

export default[
    LogIn, RegP, DialogButtons
];